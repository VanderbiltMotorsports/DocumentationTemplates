# Command Cheat Sheet

Every command the template provides, on one page. Commands not listed here
are rarely needed.

General approach: **copy a line that already works and change the words.**

---

## Setting up the document (the `FILL THIS IN` block)

```latex
\documentclass[designreport]{fsaedoc}   % or testprocedure, testreport, guide,
\input{teaminfo}                        %    study, memberintro
                                        % extra options: brief, nonumbers,
                                        %    nologo, noheadermark, a4paper

\doctitle{Front Upright Design}
\docsubtitle{Optional one-line subtitle}
\docid{SUS-DR-004}
\subsystem{Suspension}
\docstatus{Draft}            % Draft | In Review | Released | Superseded
\reviewby{2027-06-01}        % when this must be re-read. OPTIONAL: leave the
                             % line out and it defaults to 14 days after the
                             % PDF is compiled, marked "(auto)" on the cover
\supersedes{SUS-DR-003}      % delete the line if it supersedes nothing
\keywords{upright, 7075-T6, FEA}
\summary{One paragraph. Goes in the box on the cover.}

\docauthor{Daiwei Lu}{daiwei.lu@vanderbilt.edu}             % repeat per author
\docreviewer{Reviewing lead}{Lead}                          % repeat per approver

\revision{A}{2026-06-14}{D. Lu}{What changed.}              % repeat per revision
\nom{$F_z$}{Vertical wheel load}{N}                         % repeat per symbol
```

The **last** `\revision` line automatically becomes the current revision.
You never type the revision letter anywhere else. (`\docrev{C}` can force a
different letter, but you should almost never need it.)

All of these go **above** `\begin{document}`. If one is placed below it,
LaTeX stops with *"Can be used only in preamble"*, and the line needs to
move up.

The cover page, document control page, contents, and nomenclature table are
generated for you. You do not call them. Just start writing after
`\begin{document}`.

**`brief` documents** (and `memberintro`, which implies it) skip all of that
and put a compact masthead at the top of page 1 instead, so a one-page
document really is one page. Use it for anything a page or two long.

---

## Structure

```latex
\section{Scope and Objectives}
\subsection{Load Cases}
\subsubsection{Vertical}
```

Bullets and numbers work the normal way:

```latex
\begin{itemize}
  \item first thing
\end{itemize}

\begin{enumerate}
  \item first thing
\end{enumerate}
```

---

## Figures

Put the image in `figures/`. Write the name **without the extension**.

```latex
\fsfig{upright-fea}{Von Mises stress under the 3 g bump case.}
\fsfig[0.5]{upright-fea}{Half-width version.}       % optional width fraction
\fsfigfull{wide-plot}{Full width.}
\fsfigs{Overall caption}{left-img}{Left caption}{right-img}{Right caption}
```

Refer back to it anywhere with the same name:

```latex
As shown in \reffig{upright-fea}, the peak stress ...
```

For `\fsfigs`, `\reffig{left-img}` (the first filename) refers to the pair.

**One image, one `\fsfig`.** The label comes from the filename, so if you
include the same image twice, `\reffig` points at the second one. Duplicate
the file under a second name if you really need it twice.

---

## Tables

```latex
\begin{fstable}{loadcases}{Design load cases}{l r r r}%
  {Load case, $F_z$ [N], $F_y$ [N], $F_x$ [N]}
  Static          & 528  & 0    & 0 \\
  3.0 g bump      & 1584 & 0    & 0 \\
\end{fstable}
```

- **arg 1** short id for cross-references
- **arg 2** caption
- **arg 3** column layout, one letter per column: `l` left, `c` centre, `r` right
- **arg 4** headings separated by **commas** (bolded for you). A heading that
  contains a comma goes in braces: `{Mass, kg}`
- then your rows: cells separated by `&`, every row ending in `\\`

Refer back with `\reftab{loadcases}`.

**Straight from a CSV export**, with no retyping:

```latex
\fscsv{laptimes}{Lap timing}{data/lap-times.csv}
```

**Blank grid to fill in by hand** at the track (headings comma-separated,
last number is how many empty rows):

```latex
\blanktable{pedaltravel}{Pedal travel record}{Date, Bled by, {Travel, mm}, Initials}{6}
```

---

## Equations

```latex
\fseq{bending}{\sigma = \frac{M c}{I}}
```

Refer back with `\refeq{bending}`. Inline maths goes between dollar signs:
`$F_z = \qty{1584}{\newton}$`.

---

## Numbers and units

Always use `\qty`, which inserts the correct spacing and keeps units
consistent.

```latex
\qty{412}{\gram}                  412 g
\qty{243}{\mega\pascal}           243 MPa
\qty{9}{\newton\meter}            9 N m
\qty{3.0}{\gforce}                3.0 g       (g-force, not grams)
\qty{31}{\celsius}                31 °C
\qty{83}{\kilo\pascal}            83 kPa
\qty{45}{\kilo\meter\per\hour}    45 km/h
\qty{60}{\percent}                60 %
\qty{\pm 9}{\celsius}             ±9 °C
\qtyrange{5}{25}{\newton\meter}   5 to 25 N m
\ang{6.5}                         6.5°
\num{2e5}                         2 × 10⁵
```

Extras this template adds: `\gforce`, `\rpm`, `\psi`, `\inch`, `\lbf`, `\lbft`.
In a nomenclature entry, wrap a bare unit: `\unit{\celsius}`.

---

## Callout boxes

```latex
\begin{fsnote}   ... \end{fsnote}      % grey/cream, context and background
\begin{fstip}    ... \end{fstip}       % green, a shortcut or a trick
\begin{fswarn}   ... \end{fswarn}      % amber, a common mistake
\begin{fsdanger} ... \end{fsdanger}    % red, a safety hazard
\begin{fskey}    ... \end{fskey}       % gold, the main point to remember
```

Each takes an optional custom title:

```latex
\begin{fsnote}[Where these numbers came from]
Logged at 200 Hz on the front pushrod load cell.
\end{fsnote}
```

---

## Procedures

```latex
\begin{steps}
  \step Chock the rear wheels.
  \step Torque the lug nuts to \qty{110}{\newton\meter}.
        \stepnote{Italic aside under a step. Use for warnings and gotchas.}
  \step At each caliper:
        \begin{steps}
          \step Fit the tubing.
          \step Open the nipple a quarter turn.
        \end{steps}
\end{steps}
```

Tick-box lists:

```latex
\begin{checklist}
  \checkitem Fire extinguisher within reach
  \checkitem Second person present
\end{checklist}
```

Safety and setup banners (each takes one block of content):

```latex
\ppe{Safety glasses, nitrile gloves, closed-toe shoes.}
\tools{Torque wrench, 17 mm socket, catch bottle.}
\prereq{Car on stands. Battery connected, master switch off.}
\stopcondition{Any visible fluid on the ground. Smoke from any corner.}
```

---

## Requirements

```latex
\req{REQ-01}{Withstand the 3 g bump case with n >= 2.0}{FEA}
\req{REQ-02}{Total mass below \qty{450}{\gram}}{Scale measurement}

\printrequirements     % put this where you want the table
```

---

## Rules, open items, references

```latex
\fsrule{T.2.4}                                  % prints "Rule T.2.4"
\fsrule[Wheels and wheel fasteners]{T.2.4}      % with a note for the index
```

All cited rules are collected into a **FSAE Rules Referenced** table at the
end of the document, automatically.

```latex
\openitem{M. Bell}{Run a fatigue check on the ball joint fillet}{2027-01-15}
```

Renders inline as a red **[OPEN ITEM]** badge followed by the item in italics,
**and** collects into an **Open Items** table at the end of the document. Use
this instead of a `% TODO` comment, which stays invisible to readers.

```latex
... supports re-testing on any of those three changes~\citep{limpert1999}.
```

Add the entry to `refs.bib` first. The References section only appears if you
actually cite something.

---

## Small inline helpers

```latex
\partno{SUS-PT-014}      part or document numbers, monospaced
\person{Daiwei Lu}       a person's name
\filepath{Z:\textbackslash VUM}  a file path (backslashes need \textbackslash)
\term{unsprung mass}     first use of a term you are defining
\fsurl{https://...}      a clickable link
\textbf{bold}  \emph{italic}
```

Code and terminal output:

```latex
\begin{lstlisting}
Z:\VUM\_backups\YYYY-MM-DD\
\end{lstlisting}
```

---

## Common errors

| Symptom | Cause |
|---|---|
| `Undefined control sequence` | Command misspelled, or not on this page |
| Figure missing | Not in `figures/`, or you included the file extension |
| `Missing $ inserted` | `_` or `^` used outside maths mode. Wrap in `$ $` |
| Table fails to build | Wrong number of `&` in a row, or a missing `\\` |
| `??` instead of a number | Recompile, since LaTeX needs two passes |
| `%` prints nothing | `%` starts a comment. For a percent sign write `\%` |
| `&` causes table errors | For a literal ampersand write `\&` |
| `Can be used only in preamble` | A `\doctitle`/`\docauthor`/`\revision`-type line ended up below `\begin{document}` |
| `Not in outer par mode` | A `\fsfig`/`\fstable`/`\fscsv`/`\blanktable` inside a callout box. Move it outside the box |
| Every unit command fails | `\usepackage{physics}` overwrites `\qty`. Remove it |
| Windows path errors | `\` starts a command. Write `Z:\textbackslash VUM` |

Reserved characters that need a backslash: `& % $ # _ { }`
